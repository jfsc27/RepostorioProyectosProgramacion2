package co.edu.uniquindio.services;

public interface IContribuyente {
    //Aqui se utiliza la segregacion de interfaces, para poder brindarle a las clases hijas tecnico y gerente un metodo independiente a ellas;
    public void contribuir ();

}
