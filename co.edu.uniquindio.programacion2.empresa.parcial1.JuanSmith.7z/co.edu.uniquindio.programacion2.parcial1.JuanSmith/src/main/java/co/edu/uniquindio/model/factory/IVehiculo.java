package co.edu.uniquindio.model.factory;

public interface IVehiculo {
    void conducir();
}
}
