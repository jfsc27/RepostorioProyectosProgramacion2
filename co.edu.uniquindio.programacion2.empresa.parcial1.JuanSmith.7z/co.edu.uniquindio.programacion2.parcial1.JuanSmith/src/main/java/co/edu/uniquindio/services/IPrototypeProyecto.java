package co.edu.uniquindio.services;

public interface IPrototypeProyecto extends Cloneable{
    IPrototypeProyecto clone ();
}
