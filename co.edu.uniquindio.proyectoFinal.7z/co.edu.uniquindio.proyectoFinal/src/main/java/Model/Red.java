package Model;

public class Red {
}
