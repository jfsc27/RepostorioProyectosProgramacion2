package Mapping.DTO;

public record UsuarioDTO (
    String nombreUsuario,
    String contrasenia)
{
}
